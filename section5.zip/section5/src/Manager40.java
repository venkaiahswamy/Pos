class V{
	void test()
	{
System.out.println("from V test");
	}}
	class W extends V
	{
		void test()
		{
		System.out.println("from W  test ");
	}}
class X extends W
{
	void test()
		{
		System.out.println("from X  test ");
	}}
class  Manager40
{
	public static void main(String[] args) 
	{

		V v1=new V();
		V v2=new W();
		V v3=new X();
		V[] elements={v1,v2,v3};
		for(V element:elements){
			element.test();
		}

		System.out.println("done");
	}
}
