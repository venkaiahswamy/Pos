abstract class Employee
{
	abstract void work();
} 
class SoftwereEmployee extends Employee
{
	void work()
	{
System.out.println("softwere work");
	}
}
class HrEmployee extends Employee
{
	void work()
	{
		System.out.println("Hr work");
}
}
class SalesEmployee extends Employee
{
	void work()
	{
		System.out.println("sales work");
}
}
public class Manager41
{
	public static void main(String[] args) 
	{
		Employee e1=new SoftwereEmployee();
		Employee e2=new HrEmployee();
		Employee e3=new SalesEmployee();
		Employee[] employees={e1,e2,e3};
		for(Employee emp:employees)
		{
emp.work();
		}

		System.out.println("Hello World!");
	}
}
