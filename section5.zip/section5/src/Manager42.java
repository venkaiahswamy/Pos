interface Card
{
	void transfer();
}
class  CreditCard implements Card
{
	public void transfer()
	{
		System.out.println("from CreditCard");
	}
}
class DebitCard implements Card
{
	public void transfer()
	{
		System.out.println("from debit card");
	}
}
class Manager42
{
	public static void main(String[] args) 
	{
Card c1=new CreditCard();
Card c2=new DebitCard();
Card[] cards={c1,c2};
for(Card card:cards)
		{
	card.transfer();
		}

		System.out.println("Hello World!");
	}
}
