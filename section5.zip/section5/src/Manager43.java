class A 
{
	int i=10;
}
class B extends A
{
int i=20;
}
class C extends B
{
	int i=30;
}
class Manager43
{
	public static void main(String[] args) 
	{
		A a1=new C();
		B b1=(B)a1;
		C c1=(C)a1;
		System.out.println(a1.i);
		System.out.println(b1.i);
		System.out.println(c1.i);
		System.out.println(((B)c1).i);
		System.out.println(((A)(B)c1).i);
		System.out.println("Hello World!");
	}
}
