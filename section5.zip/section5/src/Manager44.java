class D 
{
	static void test()
	{
		System.out.println("from d static test");
	}
}
class E extends D
{
static void test()
	{
		System.out.println("from E static test");
	}}
	class Manager44
	{
	public static void main(String[] args) 
	{
	D d1=new D();
	D d2=new E();
	D[] elements={d1,d2};
	for(D element:elements)
		{
		element.test();
		}
		
		System.out.println("Hello World!");
	}
}
