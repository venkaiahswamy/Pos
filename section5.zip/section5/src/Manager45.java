class F 
{
	static int i=10;
	static
	{
System.out.println("from F static block");
	}
}
class G extends F
{
	static
	{
		System.out.println("from G static ");
	}
}
	class Manager45
	{
	public static void main(String[] args) 
	{
		System.out.println(G.i);
		System.out.println("Hello World!");
	}
}
