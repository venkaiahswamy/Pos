class H
{
	static void test()
	{
		System.out.println("from H test");
	}
static
	{
	System.out.println("from H sib");
	}
}
class I extends H
{
	static
	{
		System.out.println("from I sib");
	}
}
class Manager46
{
	public static void main(String[] args) 
	{

I.test();		
		System.out.println("Hello World!");
	}
}
