class T{
	void test()
	{
System.out.println("from t test");
	}}
	class U extends T
	{
		void test()
		{
		System.out.println("from u  test ");
	}}
	class Manager39
{
	public static void main(String[] args) 
	{
		T t1=new T();
		T t2=new U();
		T[] elements ={t1,t2};
		for(T element:elements)
		{
			element.test();
		}
	}
}
